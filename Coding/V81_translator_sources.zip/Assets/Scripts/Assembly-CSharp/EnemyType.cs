using UnityEngine;

[CreateAssetMenu(menuName = "ScriptableObjects/EnemyType", order = 1)]
public class EnemyType : ScriptableObject
{
	public string enemyName;

	[Header("Spawning logic")]
	[Tooltip("Determines how likely an enemy is to spawn throughout the day.")]
	public AnimationCurve probabilityCurve;

	public bool spawningDisabled;

	[Tooltip("Multiplies the spawn probability with a number based off the amount of weeds/mold growing.")]
	public bool spawnFromWeeds;

	[Tooltip("X axis is the number of this enemy type that have spawned, divided by 10; Y axis is a multiplier to probabilityCurve.")]
	public AnimationCurve numberSpawnedFalloff;

	public bool useNumberSpawnedFalloff;

	[Space(3f)]
	public int spawnInGroupsOf;

	public bool requireNestObjectsToSpawn;

	[Space(5f)]
	public GameObject enemyPrefab;

	[Tooltip("Adds to a global counter determining how many enemies can spawn.")]
	public float PowerLevel;

	[Tooltip("Adds to a global (inside or outside) counter, only once for this enemy type / species.")]
	public int DiversityPowerLevel;

	[Tooltip("An individual counter determining how many of this enemy can spawn, regardless of how many other enemies there are.")]
	public int MaxCount;

	[Space(3f)]
	public int numberSpawned;

	public int nestsSpawned;

	public bool hasSpawnedAtLeastOne;

	[Space(3f)]
	public bool isOutsideEnemy;

	[Space(3f)]
	public bool isDaytimeEnemy;

	[Space(3f)]
	public int increasedChanceInterior = -1;

	[Range(0f, 1f)]
	public float normalizedTimeInDayToLeave = 1f;

	[Space(3f)]
	[Header("Misc. ingame properties")]
	public float stunTimeMultiplier = 2f;

	public float doorSpeedMultiplier = 1f;

	public float stunGameDifficultyMultiplier = 1f;

	public bool canBeStunned = true;

	public bool canDie = true;

	public bool canBeDestroyed = true;

	public bool destroyOnDeath;

	public bool canSeeThroughFog;

	public bool disableAnimatorWhenFar;

	[Space(3f)]
	public float pushPlayerForce = 0.16f;

	public float pushPlayerDistance = 1.26f;

	[Space(3f)]
	[Tooltip("This determines where the enemy can navigate to and spawn at")]
	public NavSizeLimit SizeLimit;

	public EnemySize EnemySize;

	public EnemyWaterType WaterType;

	[Space(10f)]
	[Header("Vent Properties")]
	public float timeToPlayAudio = 15f;

	public float loudnessMultiplier = 1f;

	public AudioClip overrideVentSFX;

	[Space(5f)]
	[Header("Nest Spawn Objects")]
	public GameObject nestSpawnPrefab;

	public float nestSpawnPrefabWidth = 2f;

	public float nestDistanceFromShip = -1f;

	[Tooltip("If false, nest objects will be spawned for each instance of this enemy that gets spawned. If true, they will all share one nest object.")]
	public bool useMinEnemyThresholdForNest;

	public int minEnemiesToSpawnNest;

	[Space(5f)]
	public AudioClip hitBodySFX;

	public AudioClip hitEnemyVoiceSFX;

	public AudioClip deathSFX;

	public AudioClip stunSFX;

	public MiscAnimation[] miscAnimations;

	public AudioClip[] audioClips;
}
